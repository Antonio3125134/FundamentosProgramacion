package com.mycompany.operacionesaritmeticasmvc;

public class modelo
{
    public int suma(int x, int y)
    {
        return x + y;
    }
    
    public int resta(int x, int y)
    {
        return x - y;
    }
    
    public int multiplicacion(int x, int y)
    {
        return x * y;
    }
    
    public int division(int x, int y)
    {
        return x / y;
    }
}
