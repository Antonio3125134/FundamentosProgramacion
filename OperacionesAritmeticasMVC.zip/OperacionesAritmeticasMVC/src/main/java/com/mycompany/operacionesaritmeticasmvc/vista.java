package com.mycompany.operacionesaritmeticasmvc;
import java.util.Scanner;

public class vista 
{
    Scanner a = new Scanner(System.in);
    public int menu()
    {
        System.out.println("Elige una operacion");
        System.out.println("1.-Suma");
        System.out.println("2.-Resta");
        System.out.println("3.-Multiplicacion");
        System.out.println("4.-Division");
        return a.nextInt();
        
    }
    
    public int N1()
    {
        System.out.println("Ingresa el primer dato");
        return a.nextInt();       
    }
    
    public int N2()
    {
        System.out.println("Ingresa el segundo dato");
        return a.nextInt();       
    }
    
    public void res(double r)
    {
        System.out.println("La respuesta es; "+r);
        
    }
    public void salida()
    {
        System.out.println("Hasta Luego");
    }
    
}
