package com.mycompany.operacionesaritmeticasmvc;

public class OperacionesAritmeticasMVC {

    public static void main(String[] args) {
        
        vista v = new vista ();
        modelo b = new modelo ();
        int a = v.menu(), x, y;       
        double R;
        
        switch(a)
        {
                case 1:
                    x = v.N1();
                    y = v.N2();
                    R = b.suma(x, y);
                    v.res(R);
                    
                break;
                    
                case 2:
                    x = v.N1();
                    y = v.N2();
                    R = b.resta(x, y);
                    v.res(R);
                    
                break;
                
                case 3:
                    x = v.N1();
                    y = v.N2();
                    R = b.multiplicacion(x, y);
                    v.res(R);
                    
                break;
                
                case 4:
                    x = v.N1();
                    y = v.N2();
                    R = b.division(x, y);
                    v.res(R);
                    
                break;
                
                case 5:
                    v.salida();
                break;
                default:
        }
    
    }
}
